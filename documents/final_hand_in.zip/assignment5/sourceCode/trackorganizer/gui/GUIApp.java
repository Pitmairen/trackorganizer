
package gui;


public class GUIApp {
    
    
    
    public static void main(String[] args) {
        MainWindow w = new MainWindow();
        
        
    }
}
