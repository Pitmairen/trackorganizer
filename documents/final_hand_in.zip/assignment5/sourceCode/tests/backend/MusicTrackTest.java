package backend;

import java.time.Duration;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Alejandro Gronhaug
 */
public class MusicTrackTest {
  
    /**
     * Test of getArtist method, of class MusicTrack.
     */
    @Test
    public void gettersANDsetters() {
     MusicTrack dummyTest = new MusicTrack("Deeper Underground","Jamiroquay", Duration.ofSeconds(32));
      
    }

    /**
     * Test of setArtist method, of class MusicTrack.
     */
    @Test
    public void testSetArtist() {
      
    }
    
}
