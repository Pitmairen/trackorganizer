package backend;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 100174
 */
public class AdvertisementTrackTest {
 

    /**
     * Test of getDescriptionString method, of class AdvertisementTrack.
     */
    @Test
    public void testGetDescriptionString() {

    }

    /**
     * Test of getDescription method, of class AdvertisementTrack.
     */
    @Test
    public void testGetDescription() {

    }

    /**
     * Test of getCompany method, of class AdvertisementTrack.
     */
    @Test
    public void testGetCompany() {

    }

    /**
     * Test of setCompany method, of class AdvertisementTrack.
     */
    @Test
    public void testSetCompany() {

    }

    /**
     * Test of getProduct method, of class AdvertisementTrack.
     */
    @Test
    public void testGetProduct() {

    }

    /**
     * Test of setProduct method, of class AdvertisementTrack.
     */
    @Test
    public void testSetProduct() {

    }
    
}
